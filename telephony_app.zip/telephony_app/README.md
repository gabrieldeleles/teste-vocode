# Self-hosted Telephony Server

See https://docs.vocode.dev/open-source/telephony for setup steps!
